package org.safa.saboresdecasa.modelos;

public enum EstadoPedido {
    PENDIENTE,
    COMPLETADO,
    CANCELADO
}
