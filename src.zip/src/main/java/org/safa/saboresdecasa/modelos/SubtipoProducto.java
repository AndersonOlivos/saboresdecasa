package org.safa.saboresdecasa.modelos;

public enum SubtipoProducto {
    TOSTADA, DULCE, CEREAL
}
