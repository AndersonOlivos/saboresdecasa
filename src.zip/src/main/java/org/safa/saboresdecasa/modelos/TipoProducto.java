package org.safa.saboresdecasa.modelos;

public enum TipoProducto {
    REFRESCO, COMIDA, BEBIDA_CALIENTE, SMOTHIE
}
